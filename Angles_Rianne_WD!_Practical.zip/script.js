const $ = id => document.getElementById(id);

let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
let editIndex = -1;

$("expenseForm").onsubmit = e => {
    e.preventDefault();

    const name = $("name").value.trim();
    const amount = +$("amount").value;
    const category = $("category").value;

    if (!name || amount <= 0) return alert("Invalid input!");

    const data = { name, amount, category };

    editIndex === -1 ? expenses.push(data) : expenses[editIndex] = data;
    editIndex = -1;

    save();
    render();
    e.target.reset();
};

const save = () => localStorage.setItem("expenses", JSON.stringify(expenses));

const del = i => confirm("Delete?") && (expenses.splice(i,1), save(), render());

const edit = i => {
    let e = expenses[i];
    $("name").value = e.name;
    $("amount").value = e.amount;
    $("category").value = e.category;
    editIndex = i;
};

const render = () => {
    const filter = $("filter").value;
    const sort = $("sort").value;

    let data = [...expenses]
        .filter(e => filter === "All" || e.category === filter)
        .sort((a,b)=> sort==="asc"?a.amount-b.amount: sort==="desc"?b.amount-a.amount:0);

    $("list").innerHTML = "";
    let total = 0;

    data.forEach((e,i)=>{
        total += e.amount;
        $("list").innerHTML += `
            <li class="${e.category}">
                ${e.name} - ₱${e.amount}
                <div>
                    <button onclick="edit(${i})">Edit</button>
                    <button onclick="del(${i})">X</button>
                </div>
            </li>`;
    });

    $("total").textContent = total;
    drawChart();
};

["filter","sort"].forEach(id => $(id).onchange = render);

document.addEventListener("keydown", e => {
    if (e.key === "Enter") $("expenseForm").requestSubmit();
});

$("darkModeToggle").onclick = () => document.body.classList.toggle("dark");

const drawChart = () => {
    const ctx = $("chart").getContext("2d");
    ctx.clearRect(0,0,300,200);

    let t = {Food:0, Transport:0, Bills:0, Others:0};
    expenses.forEach(e => t[e.category]+=e.amount);

    let x = 10;
    Object.entries(t).forEach(([k,v])=>{
        let h = v/5;
        ctx.fillRect(x,200-h,40,h);
        ctx.fillText(k,x,195);
        x+=60;
    });
};

render();